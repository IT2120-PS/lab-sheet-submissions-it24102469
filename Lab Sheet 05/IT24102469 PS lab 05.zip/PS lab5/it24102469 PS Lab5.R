library(readr)
setwd("C:\\Users\\it24102469\\Desktop\\PS lab5")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
View(Delivery_Times)
str(Delivery_Times)
# 2. Histogram with 9 intervals (20 to 70)
hist(Delivery_Times$Delivery_Time_.minutes., 
     breaks = seq(20, 70, by = 5.555), 
     right = FALSE, 
     main = "Delivery Times Histogram", 
     xlab = "Minutes", 
     ylab = "Frequency", 
     col = "lightblue")

# 3. Distribution comment

# 4. Cumulative frequency polygon (ogive)
freq_table <- hist(Delivery_Times$Delivery_Time_.minutes., 
                   breaks = seq(20, 70, by = 5.555), 
                   right = FALSE, 
                   plot = FALSE)
cum_freq <- cumsum(freq_table$counts)
plot(freq_table$breaks[-1], cum_freq, 
     type = "l", 
     main = "Ogive of Delivery Times", 
     xlab = "Minutes", 
     ylab = "Cumulative Frequency", 
     col = "blue")
points(freq_table$breaks[-1], cum_freq, pch = 16, col = "blue")